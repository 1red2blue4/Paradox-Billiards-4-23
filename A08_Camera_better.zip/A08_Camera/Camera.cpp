#include "Camera.h"


Camera::Camera()
{
	m_m4Projection = glm::perspective(45.0f, 1080.0f / 768.0f, 0.01f, 1000.0f);
	m_m4View = matrix4();

	up = vector3(0.0f, 1.0f, 0.0f);
	right = vector3(0.0f, 0.0f, 1.0f);
	forward = vector3(-1.0f, 0.0f, 0.0f);
}

Camera::~Camera()
{

}

matrix4 Camera::GetView()
{
	return m_m4View;
}

matrix4 Camera::GetProjection(bool bOrthographic)
{
	return m_m4Projection;
}

void Camera::SetPosition(vector3 v3Position)
{
	/*
	matrix4 tempPosition = m_m4View;
	vector3 oldPosition = vector3(m_m4View[3][0], m_m4View[3][1], m_m4View[3][2]);
	m_m4View[3][0] = 0;
	m_m4View[3][1] = 0;
	m_m4View[3][2] = 0;
	*/

	m_m4View = glm::translate(IDENTITY_M4, -v3Position);
}

void Camera::SetTarget(vector3 v3Target)
{
	/*
	matrix4 tempPosition = m_m4Projection;
	m_m4Projection = glm::translate(IDENTITY_M4, v3Target);
	*/
}

void Camera::SetUp(vector3 v3Up)
{
	//quaternion upQuat = quaternion();
	vector3 oldPosition = vector3(m_m4View[3][0], m_m4View[3][1], m_m4View[3][2]);
	m_m4View = glm::translate(IDENTITY_M4, oldPosition);
	quaternion rotation = quaternion();
	m_m4View = m_m4View * ToMatrix4(rotation);
}

void Camera::MoveForward(float fIncrement)
{
	/*
	vector3 savedPosition = vector3(m_m4View[3][0], m_m4View[3][1], m_m4View[3][2]);
	vector3 savedRotationsR1 = vector3(m_m4View[0][0], m_m4View[0][1], m_m4View[0][2]);
	vector3 savedRotationsR2 = vector3(m_m4View[1][0], m_m4View[1][1], m_m4View[1][2]);
	vector3 savedRotationsR3 = vector3(m_m4View[2][0], m_m4View[2][1], m_m4View[2][2]);
	matrix4 rotationMatrix = matrix4(m_m4View[0][0], m_m4View[0][1], m_m4View[0][2], 0,
		m_m4View[1][0], m_m4View[1][1], m_m4View[1][2], 0,
		m_m4View[2][0], m_m4View[2][1], m_m4View[2][2], 0,
		0, 0, 0, 1);
	m_m4View = glm::translate(IDENTITY_M4, vector3(0.0f, 0.0f, fIncrement));
	m_m4View = glm::translate(m_m4View, savedPosition);
	m_m4View = m_m4View * rotationMatrix;
	*/

	m_m4View = glm::translate(m_m4View, vector3(0.0f, 0.0f, fIncrement));
}

void Camera::MoveSideways(float fIncrement)
{
	/*
	vector3 savedPosition = vector3(m_m4View[3][0], m_m4View[3][1], m_m4View[3][2]);
	vector3 savedRotationsR1 = vector3(m_m4View[0][0], m_m4View[0][1], m_m4View[0][2]);
	vector3 savedRotationsR2 = vector3(m_m4View[1][0], m_m4View[1][1], m_m4View[1][2]);
	vector3 savedRotationsR3 = vector3(m_m4View[2][0], m_m4View[2][1], m_m4View[2][2]);
	matrix4 rotationMatrix = matrix4(m_m4View[0][0], m_m4View[0][1], m_m4View[0][2], 0,
		m_m4View[1][0], m_m4View[1][1], m_m4View[1][2], 0,
		m_m4View[2][0], m_m4View[2][1], m_m4View[2][2], 0,
		0, 0, 0, 1);
	m_m4View = glm::translate(IDENTITY_M4, vector3(-fIncrement, 0.0f, 0.0f));
	m_m4View = glm::translate(m_m4View, savedPosition);
	m_m4View = m_m4View * rotationMatrix;
	*/

	m_m4View = glm::translate(m_m4View, vector3(-fIncrement, 0.0f, 0.0f));
}

void Camera::MoveVertical(float fIncrement)
{
	/*
	vector3 savedPosition = vector3(m_m4View[3][0], m_m4View[3][1], m_m4View[3][2]);
	vector3 savedRotationsR1 = vector3(m_m4View[0][0], m_m4View[0][1], m_m4View[0][2]);
	vector3 savedRotationsR2 = vector3(m_m4View[1][0], m_m4View[1][1], m_m4View[1][2]);
	vector3 savedRotationsR3 = vector3(m_m4View[2][0], m_m4View[2][1], m_m4View[2][2]);
	matrix4 rotationMatrix = matrix4(m_m4View[0][0], m_m4View[0][1], m_m4View[0][2], 0,
		m_m4View[1][0], m_m4View[1][1], m_m4View[1][2], 0,
		m_m4View[2][0], m_m4View[2][1], m_m4View[2][2], 0,
		0, 0, 0, 1);
	m_m4View = rotationMatrix;
	m_m4View = glm::translate(m_m4View, vector3(0.0f, -fIncrement, 0.0f));
	m_m4View = glm::translate(m_m4View, savedPosition);
	*/
	
	m_m4View = glm::translate(m_m4View, vector3(0.0f, -fIncrement, 0.0f));
}

void Camera::ChangePitch(float fIncrement)
{
	quaternion rotation = glm::angleAxis(-fIncrement, forward);
	vector3 savedPosition = vector3(m_m4View[3][0], m_m4View[3][1], m_m4View[3][2]);
	
	forward = rotation * forward;
	m_m4View = ToMatrix4(rotation);
	m_m4View = glm::translate(m_m4View, savedPosition);
}

void Camera::ChangeRoll(float fIncrement)
{
	quaternion rotation = glm::angleAxis(-fIncrement, right);
	vector3 savedPosition = vector3(m_m4View[3][0], m_m4View[3][1], m_m4View[3][2]);

	right = rotation * right;
	m_m4View = ToMatrix4(rotation);
	m_m4View = glm::translate(m_m4View, savedPosition);
}

void Camera::ChangeYaw(float fIncrement)
{
	quaternion rotation = glm::angleAxis(-fIncrement, up);
	vector3 savedPosition = vector3(m_m4View[3][0], m_m4View[3][1], m_m4View[3][2]);

	up = rotation * up;
	m_m4View = ToMatrix4(rotation);
	m_m4View = glm::translate(m_m4View, savedPosition);
}