#include "MyBoundingBoxClass.h"

MyBoundingBoxClass::MyBoundingBoxClass(std::vector<vector3> vertexList)
{
	m_bColliding = false;
	m_fRadius = 0.0f;
	m_v3CenterGlobal = vector3(0.0f);
	m_v3CenterNewLocal = vector3(0.0f);
	m_v3NewSize = vector3(0.0f);
	m_v3Size = vector3(0.0f);

	if (vertexList.size() < 1)
		return;

	m_v3Min = vertexList[0];
	m_v3Max = vertexList[0];

	for (int i = 1; i < vertexList.size(); i++)
	{
		//vector3 myVertex = vector3(ToMatrix4(m_qArcBall) * vector4(vertexList[i], 1));
		if (m_v3Min.x > vertexList[i].x)
		{
			m_v3Min.x = vertexList[i].x;
		}
		else if (m_v3Max.x < vertexList[i].x)
		{
			m_v3Max.x = vertexList[i].x;
		}

		if (m_v3Min.y > vertexList[i].y)
		{
			m_v3Min.y = vertexList[i].y;
		}
		else if (m_v3Max.y < vertexList[i].y)
		{
			m_v3Max.y = vertexList[i].y;
		}

		if (m_v3Min.z > vertexList[i].z)
		{
			m_v3Min.z = vertexList[i].z;
		}
		else if (m_v3Max.z < vertexList[i].z)
		{
			m_v3Max.z = vertexList[i].z;
		}
	}

	m_v3MinGlobal = m_v3Min;
	m_v3MaxGlobal = m_v3Max;

	m_v3CenterLocal = m_v3CenterGlobal = (m_v3Max + m_v3Min) / 2.0f;
	m_v3CenterNewLocal = m_v3CenterGlobal = (m_v3Max + m_v3Min) / 2.0f;

	m_fRadius = glm::distance(m_v3CenterGlobal, m_v3Max);

	m_pMeshMngr = MeshManagerSingleton::GetInstance();
	m_v3Size.x = glm::distance(vector3(m_v3Min.x, 0.0f, 0.0f), vector3(m_v3Max.x, 0.0f, 0.0f));
	m_v3Size.y = glm::distance(vector3(0.0f, m_v3Min.y, 0.0f), vector3(0.0f, m_v3Max.y, 0.0f));
	m_v3Size.z = glm::distance(vector3(0.0f, 0.0f, m_v3Min.z), vector3(0.0f, 0.0f, m_v3Max.z));

	m_v3NewSize.x = glm::distance(vector3(m_v3Min.x, 0.0f, 0.0f), vector3(m_v3Max.x, 0.0f, 0.0f));
	m_v3NewSize.y = glm::distance(vector3(0.0f, m_v3Min.y, 0.0f), vector3(0.0f, m_v3Max.y, 0.0f));
	m_v3NewSize.z = glm::distance(vector3(0.0f, 0.0f, m_v3Min.z), vector3(0.0f, 0.0f, m_v3Max.z));
}

void MyBoundingBoxClass::FindOrthoBox(quaternion rotationArc)
{
	m_vOrthoMax = m_v3Max;
	m_vOrthoMin = m_v3Min;

	vector3 maxXmaxYmaxZ = vector3(m_vOrthoMax.x, m_vOrthoMax.y, m_vOrthoMax.z);
	vector3 maxXmaxYminZ = vector3(m_vOrthoMax.x, m_vOrthoMax.y, m_vOrthoMin.z);
	vector3 maxXminYmaxZ = vector3(m_vOrthoMax.x, m_vOrthoMin.y, m_vOrthoMax.z);
	vector3 maxXminYminZ = vector3(m_vOrthoMax.x, m_vOrthoMin.y, m_vOrthoMin.z);
	vector3 minXmaxYmaxZ = vector3(m_vOrthoMin.x, m_vOrthoMax.y, m_vOrthoMax.z);
	vector3 minXmaxYminZ = vector3(m_vOrthoMin.x, m_vOrthoMax.y, m_vOrthoMin.z);
	vector3 minXminYmaxZ = vector3(m_vOrthoMin.x, m_vOrthoMin.y, m_vOrthoMax.z);
	vector3 minXminYminZ = vector3(m_vOrthoMin.x, m_vOrthoMin.y, m_vOrthoMin.z);
	std::vector<vector3> newMinMaxes = { maxXmaxYmaxZ, maxXmaxYminZ, maxXminYmaxZ, maxXminYminZ, minXmaxYmaxZ, minXmaxYminZ, minXminYmaxZ, minXminYminZ };

	m_v3NewMin = vector3(ToMatrix4(rotationArc) * vector4(newMinMaxes[0], 1.0f));
	m_v3NewMax = vector3(ToMatrix4(rotationArc) * vector4(newMinMaxes[0], 1.0f));

	for (int i = 1; i < newMinMaxes.size(); i++)
	{
		vector3 myVector = vector3(ToMatrix4(rotationArc) * vector4(newMinMaxes[i], 1.0f));
		if (m_v3NewMin.x > myVector.x)
		{
			m_v3NewMin.x = myVector.x;
		}
		else if (m_v3NewMax.x < myVector.x)
		{
			m_v3NewMax.x = myVector.x;
		}

		if (m_v3NewMin.y > myVector.y)
		{
			m_v3NewMin.y = myVector.y;
		}
		else if (m_v3NewMax.y < myVector.y)
		{
			m_v3NewMax.y = myVector.y;
		}

		if (m_v3NewMin.z > myVector.z)
		{
			m_v3NewMin.z = myVector.z;
		}
		else if (m_v3NewMax.z < myVector.z)
		{
			m_v3NewMax.z = myVector.z;
		}
	}

	m_v3CenterNewLocal = (m_v3NewMax + m_v3NewMin) / 2.0f;

	m_v3NewSize.x = glm::distance(vector3(m_v3NewMin.x, 0.0f, 0.0f), vector3(m_v3NewMax.x, 0.0f, 0.0f));
	m_v3NewSize.y = glm::distance(vector3(0.0f, m_v3NewMin.y, 0.0f), vector3(0.0f, m_v3NewMax.y, 0.0f));
	m_v3NewSize.z = glm::distance(vector3(0.0f, 0.0f, m_v3NewMin.z), vector3(0.0f, 0.0f, m_v3NewMax.z));

	tempRot = rotationArc;
}

void MyBoundingBoxClass::SetNewBox()
{
	vector3 maxXmaxYmaxZ = vector3(m_v3Max.x, m_v3Max.y, m_v3Max.z);
	vector3 maxXmaxYminZ = vector3(m_v3Max.x, m_v3Max.y, m_v3Min.z);
	vector3 maxXminYmaxZ = vector3(m_v3Max.x, m_v3Min.y, m_v3Max.z);
	vector3 maxXminYminZ = vector3(m_v3Max.x, m_v3Min.y, m_v3Min.z);
	vector3 minXmaxYmaxZ = vector3(m_v3Min.x, m_v3Max.y, m_v3Max.z);
	vector3 minXmaxYminZ = vector3(m_v3Min.x, m_v3Max.y, m_v3Min.z);
	vector3 minXminYmaxZ = vector3(m_v3Min.x, m_v3Min.y, m_v3Max.z);
	vector3 minXminYminZ = vector3(m_v3Min.x, m_v3Min.y, m_v3Min.z);
	std::vector<vector3> newMinMaxes = { maxXmaxYmaxZ, maxXmaxYminZ, maxXminYmaxZ, maxXminYminZ, minXmaxYmaxZ, minXmaxYminZ, minXminYmaxZ, minXminYminZ };

	m_v3NewMin = newMinMaxes[0];
	m_v3NewMax = newMinMaxes[0];

	for (int i = 1; i < newMinMaxes.size(); i++)
	{
		if (m_v3NewMin.x > newMinMaxes[i].x)
		{
			m_v3NewMin.x = newMinMaxes[i].x;
		}
		else if (m_v3NewMax.x < newMinMaxes[i].x)
		{
			m_v3NewMax.x = newMinMaxes[i].x;
		}

		if (m_v3NewMin.y > newMinMaxes[i].y)
		{
			m_v3NewMin.y = newMinMaxes[i].y;
		}
		else if (m_v3NewMax.y < newMinMaxes[i].y)
		{
			m_v3NewMax.y = newMinMaxes[i].y;
		}

		if (m_v3NewMin.z > newMinMaxes[i].z)
		{
			m_v3NewMin.z = newMinMaxes[i].z;
		}
		else if (m_v3NewMax.z < newMinMaxes[i].z)
		{
			m_v3NewMax.z = newMinMaxes[i].z;
		}
	}

	m_v3CenterNewLocal = (m_v3NewMax + m_v3NewMin) / 2.0f;

	m_v3NewSize.x = glm::distance(vector3(m_v3NewMin.x, 0.0f, 0.0f), vector3(m_v3NewMax.x, 0.0f, 0.0f));
	m_v3NewSize.y = glm::distance(vector3(0.0f, m_v3NewMin.y, 0.0f), vector3(0.0f, m_v3NewMax.y, 0.0f));
	m_v3NewSize.z = glm::distance(vector3(0.0f, 0.0f, m_v3NewMin.z), vector3(0.0f, 0.0f, m_v3NewMax.z));
}

void MyBoundingBoxClass::Render()
{
	vector3 v3Color = REGREEN;
	if (m_bColliding)
	{
		v3Color = RERED;
	}
	if (true == m_bColliding)
		v3Color = RERED;

	//add local bounding box
	m_pMeshMngr->AddCubeToRenderList(
		m_m4ToWorld *
		glm::translate(m_v3CenterLocal) *
		glm::scale(m_v3Size), v3Color, WIRE);



	//add changed bounding box
	m_pMeshMngr->AddCubeToRenderList(
		m_m4ToNewWorld * 
		glm::inverse(ToMatrix4(tempRot)) *
		glm::translate(m_v3CenterNewLocal) *
		glm::scale(m_v3NewSize), 
		v3Color, WIRE);

	/*
	m_pMeshMngr->AddCubeToRenderList(
		glm::translate(m_v3CenterGlobal) *
		glm::scale(m_v3Size), v3Color, WIRE);
	*/

	/*
	m_pMeshMngr->AddSphereToRenderList(
		glm::translate(m_v3CenterGlobal) *
		glm::scale(vector3(m_fRadius) * 2.0f), v3Color, WIRE);
	*/
}
void MyBoundingBoxClass::SetModelMatrix(matrix4 a_m4ToWorld)
{
	if (m_m4ToWorld == a_m4ToWorld)
		return;

	m_m4ToWorld = a_m4ToWorld;
	m_v3CenterGlobal = vector3(m_m4ToWorld * vector4(m_v3CenterLocal, 1.0f));
	m_v3MinGlobal = vector3(m_m4ToWorld * vector4(m_v3Min, 1.0f));
	m_v3MaxGlobal = vector3(m_m4ToWorld * vector4(m_v3Max, 1.0f));



	m_m4ToNewWorld = a_m4ToWorld;
	m_v3CenterNewGlobal = vector3(m_m4ToNewWorld * vector4(m_v3CenterNewLocal, 1.0f));
	m_v3MinNewGlobal = vector3(m_m4ToNewWorld * vector4(m_v3NewMin, 1.0f));
	m_v3MaxNewGlobal = vector3(m_m4ToNewWorld * vector4(m_v3NewMax, 1.0f));
	//m_m4ToNewWorld = m_m4ToNewWorld * glm::translate(m_v3CenterGlobal);
}



bool MyBoundingBoxClass::IsColliding(MyBoundingBoxClass* other)
{

	if (this->m_v3MaxGlobal.x < other->m_v3MinGlobal.x)
	{
		return false;
	}
	if (this->m_v3MinGlobal.x > other->m_v3MaxGlobal.x)
	{
		return false;
	}

	if (this->m_v3MaxGlobal.y < other->m_v3MinGlobal.y)
	{
		return false;
	}
	if (this->m_v3MinGlobal.y > other->m_v3MaxGlobal.y)
	{
		return false;
	}

	if (this->m_v3MaxGlobal.z < other->m_v3MinGlobal.z)
	{
		return false;
	}
	if (this->m_v3MinGlobal.z > other->m_v3MaxGlobal.z)
	{
		return false;
	}

	return true;
}

void MyBoundingBoxClass::SetColliding(bool input) { m_bColliding = input; }
void MyBoundingBoxClass::SetCenterLocal(vector3 input) { m_v3CenterLocal = input; }
void MyBoundingBoxClass::SetCenterGlobal(vector3 input) { m_v3CenterGlobal = input; }
void MyBoundingBoxClass::SetRadius(float input) { m_fRadius = input; }
bool MyBoundingBoxClass::GetColliding(void) { return m_bColliding; }
vector3 MyBoundingBoxClass::GetCenterLocal(void) { return m_v3CenterLocal; }
vector3 MyBoundingBoxClass::GetCenterGlobal(void) { return m_v3CenterGlobal; }
float MyBoundingBoxClass::GetRadius(void) { return m_fRadius; }
matrix4 MyBoundingBoxClass::GetModelMatrix(void) { return m_m4ToWorld; }